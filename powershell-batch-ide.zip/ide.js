// PowerShell/Batch Visual IDE - JavaScript Functionality

// Global variables
let editor;
let currentLanguage = 'powershell';
let currentTheme = 'vs-dark';
let currentFileName = 'script.ps1';
let projectFiles = {
    'script.ps1': {
        content: [
            '# PowerShell Script',
            '# This is a sample PowerShell script',
            'Write-Host "Hello, World!"',
            '',
            '# You can create GUI applications like this:',
            '# Add-Type -AssemblyName System.Windows.Forms',
            '# $form = New-Object System.Windows.Forms.Form',
            '# $form.Text = "My Application"',
            '# $form.Size = New-Object System.Drawing.Size(300,200)',
            '# $form.ShowDialog()'
        ].join('\n'),
        language: 'powershell'
    },
    'batch.cmd': {
        content: [
            '@echo off',
            'REM This is a sample batch file',
            'echo Hello, World!',
            'pause'
        ].join('\n'),
        language: 'batch'
    }
};

// Initialize the IDE when the page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeEditor();
    setupEventListeners();
    updateStatusBar();
});

// Initialize Monaco Editor
function initializeEditor() {
    require.config({ paths: { 'vs': 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.34.0/min/vs' }});
    require(['vs/editor/editor.main'], function() {
        editor = monaco.editor.create(document.getElementById('editor'), {
            value: [
                '# PowerShell Script',
                '# This is a sample PowerShell script',
                'Write-Host "Hello, World!"',
                '',
                '# You can create GUI applications like this:',
                '# Add-Type -AssemblyName System.Windows.Forms',
                '# $form = New-Object System.Windows.Forms.Form',
                '# $form.Text = "My Application"',
                '# $form.Size = New-Object System.Drawing.Size(300,200)',
                '# $form.ShowDialog()'
            ].join('\n'),
            language: 'powershell',
            theme: 'vs-dark',
            automaticLayout: true,
            minimap: {
                enabled: true
            },
            fontSize: 14,
            scrollBeyondLastLine: false,
            wordWrap: 'on'
        });
        
        // Register Batch file language
        monaco.languages.register({ id: 'batch' });
        
        // Define Batch file syntax highlighting
        monaco.languages.setMonarchTokensProvider('batch', {
            tokenizer: {
                root: [
                    [/^(\s*)(rem\b.*)$/, ['white', 'comment']],
                    [/^(\s*)(@?echo\b.*)$/, ['white', 'string']],
                    [/(::.*$)/, 'comment'],
                    [/(^[A-Za-z]*:)/, 'tag'], // labels
                    [/(goto\b)/, 'keyword'],
                    [/(call\b)/, 'keyword'],
                    [/(\b(?:if|else|for|do|while|break|continue)\b)/, 'keyword'],
                    [/(\b(?:dir|copy|del|move|ren|md|rd|cls|echo|set|path|pause|exit|type|find|more|sort|date|time|ver|vol|diskcomp|diskcopy|format|label|mode|print|prompt|color|title|pushd|popd|shift|start|assoc|ftype|help|timeout|tasklist|taskkill|reg|schtasks|net|ping|ipconfig|systeminfo|driverquery|nslookup|at|whoami|eventcreate|eventquery|eventtriggers|getmac|logman|openfiles|perfmon|psr|pwlauncher|rcp|repair-bde|replace|robocopy|runas|rwinsta|sc|takeown|tcmsetup|tpmvscmgr|tzutil|typeperf|w32tm|waitfor|wbadmin|wecutil|wevtutil|winrm|winrs|bitsadmin|certreq|certutil|chkdsk|chkntfs|cipher|clip|cmdkey|compact|convert|defrag|diskpart|doskey|driverquery|expand|extract|fc|fsutil|ftype|gpresult|gpupdate|icacls|klist|ksetup|logman|makecab|mountvol|openfiles|pnputil|powercfg|print|recover|regini|reg|schtasks|secpol|setx|tree|typeperf|verify|wevtutil|wmic|wusa)\b)/, 'keyword'],
                    [/(%[^%]*%)/, 'variable'], // environment variables
                    [/(%%\w+%%)/, 'variable'], // special variables
                    [/(\d+)/, 'number'],
                    [/("[^"]*")/, 'string'],
                    [/(<)([^>]*)(>)/, ['delimiter', 'identifier', 'delimiter']],
                ]
            }
        });
        
        // Define Batch file completion items
        monaco.languages.registerCompletionItemProvider('batch', {
            provideCompletionItems: function(model, position) {
                var suggestions = [
                    {
                        label: 'echo',
                        kind: monaco.languages.CompletionItemKind.Keyword,
                        insertText: 'echo ',
                        detail: 'Displays messages, or turns command echoing on or off.'
                    },
                    {
                        label: 'set',
                        kind: monaco.languages.CompletionItemKind.Keyword,
                        insertText: 'set ',
                        detail: 'Displays, sets, or removes cmd.exe environment variables.'
                    },
                    {
                        label: 'if',
                        kind: monaco.languages.CompletionItemKind.Keyword,
                        insertText: 'if ',
                        detail: 'Performs conditional processing in batch programs.'
                    },
                    {
                        label: 'for',
                        kind: monaco.languages.CompletionItemKind.Keyword,
                        insertText: 'for ',
                        detail: 'Runs a specified command for each file in a set of files.'
                    }
                ];
                return { suggestions: suggestions };
            }
        });
    });
}

// Set up event listeners for UI elements
function setupEventListeners() {
    // File menu button
    document.getElementById('fileMenuBtn').addEventListener('click', function() {
        document.getElementById('newFileModal').style.display = 'flex';
    });
    
    // Project menu button
    document.getElementById('projectMenuBtn').addEventListener('click', function() {
        document.getElementById('newProjectModal').style.display = 'flex';
    });
    
    // Open file button
    document.getElementById('openFileBtn').addEventListener('click', function() {
        openFile();
    });
    
    // Save file button
    document.getElementById('saveFileBtn').addEventListener('click', function() {
        saveFile();
    });
    
    // Close modal buttons
    document.querySelectorAll('.close-button').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });
    
    // Cancel new file button
    document.getElementById('cancelNewFileBtn').addEventListener('click', function() {
        document.getElementById('newFileModal').style.display = 'none';
    });
    
    // Create new file button
    document.getElementById('createNewFileBtn').addEventListener('click', function() {
        createNewFile();
    });
    
    // Module manager button
    document.getElementById('moduleManagerBtn').addEventListener('click', function() {
        openModuleManager();
    });
    
    // Close module manager button
    document.getElementById('closeModuleManagerBtn').addEventListener('click', function() {
        document.getElementById('moduleManagerModal').style.display = 'none';
    });
    
    // GUI Builder button
    document.getElementById('guiBuilderBtn').addEventListener('click', function() {
        openGuiBuilder();
    });
    
    // Editor tab switching
    document.querySelectorAll('.editor-tab').forEach(tab => {
        tab.addEventListener('click', function() {
            switchEditorTab(this);
        });
    });
    
    // Run button
    document.getElementById('runBtn').addEventListener('click', function() {
        runScript();
    });
    
    // Debug button
    document.getElementById('debugBtn').addEventListener('click', function() {
        debugScript();
    });
    
    // Stop button
    document.getElementById('stopBtn').addEventListener('click', function() {
        stopScript();
    });
    
    // Clear output button
    document.querySelector('.output-content').addEventListener('click', function() {
        clearOutput();
    });
    
    // Sidebar item selection
    document.querySelectorAll('.sidebar-item').forEach(item => {
        item.addEventListener('click', function() {
            selectSidebarItem(this);
        });
    });
    
    // GUI component selection
    document.querySelectorAll('.gui-component').forEach(component => {
        component.addEventListener('click', function() {
            selectGuiComponent(this);
        });
    });
    
    // Template item selection
    document.querySelectorAll('.template-item').forEach(item => {
        item.addEventListener('click', function() {
            // Highlight selected template
            document.querySelectorAll('.template-item').forEach(i => {
                i.style.borderColor = '';
            });
            this.style.borderColor = var(--accent-light);
        });
    });
    
    // Create project button
    document.getElementById('createProjectBtn').addEventListener('click', function() {
        createProject();
    });
    
    // Cancel new project button
    document.getElementById('cancelNewProjectBtn').addEventListener('click', function() {
        document.getElementById('newProjectModal').style.display = 'none';
    });
}

// Switch between editor tabs
function switchEditorTab(tabElement) {
    // Remove active class from all tabs
    document.querySelectorAll('.editor-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Add active class to clicked tab
    tabElement.classList.add('active');
    
    // Change editor language based on tab
    if (tabElement.textContent.includes('.ps1')) {
        currentLanguage = 'powershell';
        monaco.editor.setModelLanguage(editor.getModel(), 'powershell');
        document.querySelector('.status-bar div:first-child').innerHTML = '<i class="fas fa-code"></i> PowerShell Mode';
    } else if (tabElement.textContent.includes('.cmd') || tabElement.textContent.includes('.bat')) {
        currentLanguage = 'batch';
        monaco.editor.setModelLanguage(editor.getModel(), 'batch');
        document.querySelector('.status-bar div:first-child').innerHTML = '<i class="fas fa-code"></i> Batch Mode';
    }
}

// Create a new file
function createNewFile() {
    const fileName = document.getElementById('fileName').value;
    const fileType = document.getElementById('fileType').value;
    const template = document.getElementById('template').value;
    
    if (!fileName) {
        alert('Please enter a file name');
        return;
    }
    
    // Add file extension if not provided
    let fullFileName = fileName;
    if (!fileName.includes('.')) {
        fullFileName = fileName + '.' + fileType;
    }
    
    let content = '';
    let language = 'powershell';
    
    // Set content based on template
    switch (template) {
        case 'empty':
            content = '';
            break;
        case 'cli':
            if (fileType === 'ps1') {
                content = [
                    '# CLI PowerShell Script',
                    'param(',
                    '    [string]$Parameter1,',
                    '    [int]$Parameter2',
                    ')',
                    '',
                    'Write-Host "Parameter1: $Parameter1"',
                    'Write-Host "Parameter2: $Parameter2"',
                    '',
                    '# Your code here',
                    ''
                ].join('\n');
                language = 'powershell';
            } else {
                content = [
                    '@echo off',
                    'REM CLI Batch Script',
                    'set Parameter1=%1',
                    'set Parameter2=%2',
                    '',
                    'echo Parameter1: %Parameter1%',
                    'echo Parameter2: %Parameter2%',
                    '',
                    'REM Your code here',
                    'pause',
                    ''
                ].join('\n');
                language = 'batch';
            }
            break;
        case 'gui':
            if (fileType === 'ps1') {
                content = [
                    '# GUI PowerShell Application',
                    'Add-Type -AssemblyName System.Windows.Forms',
                    '',
                    '# Create form',
                    '$form = New-Object System.Windows.Forms.Form',
                    '$form.Text = "My Application"',
                    '$form.Size = New-Object System.Drawing.Size(400,300)',
                    '$form.StartPosition = "CenterScreen"',
                    '',
                    '# Add controls here',
                    '# Example:',
                    '# $button = New-Object System.Windows.Forms.Button',
                    '# $button.Text = "Click Me"',
                    '# $button.Location = New-Object System.Drawing.Point(150,100)',
                    '# $form.Controls.Add($button)',
                    '',
                    '# Show form',
                    '$form.ShowDialog() | Out-Null',
                    ''
                ].join('\n');
                language = 'powershell';
            } else {
                content = [
                    '@echo off',
                    'REM GUI Batch Application is limited',
                    'REM Batch files are primarily CLI-based',
                    'REM For GUI applications, PowerShell is recommended',
                    '',
                    'echo This is a batch file - GUI creation is limited',
                    'echo Consider using PowerShell for GUI applications',
                    'pause',
                    ''
                ].join('\n');
                language = 'batch';
            }
            break;
        case 'module':
            if (fileType === 'ps1') {
                content = [
                    '# PowerShell Module',
                    'function Get-MyFunction {',
                    '    [CmdletBinding()]',
                    '    param(',
                    '        [Parameter(Mandatory=$true)]',
                    '        [string]$InputParameter',
                    '    )',
                    '    ',
                    '    # Your code here',
                    '    Write-Host "Processing $InputParameter"',
                    '}',
                    '',
                    'Export-ModuleMember -Function Get-MyFunction',
                    ''
                ].join('\n');
                language = 'powershell';
            } else {
                content = [
                    '@echo off',
                    'REM Batch Module (Subroutine)',
                    'goto :eof',
                    '',
                    ':MyFunction',
                    'REM Your code here',
                    'echo Processing %1',
                    'goto :eof',
                    ''
                ].join('\n');
                language = 'batch';
            }
            break;
    }
    
    // Add file to project
    projectFiles[fullFileName] = {
        content: content,
        language: language
    };
    
    // Update editor with new content
    editor.setValue(content);
    currentFileName = fullFileName;
    
    // Update sidebar
    updateSidebar();
    
    // Close modal
    document.getElementById('newFileModal').style.display = 'none';
    
    // Reset form
    document.getElementById('fileName').value = '';
    document.getElementById('fileType').value = 'ps1';
    document.getElementById('template').value = 'empty';
    
    // Update status bar
    updateStatusBar();
    
    // Update editor tab
    updateEditorTab(fullFileName);
}

// Create project from template
function createProjectFromTemplate(templateName) {
    // Clear existing project files
    projectFiles = {};
    
    // Add template files based on project type
    switch (templateName) {
        case 'cli-app':
            projectFiles['main.ps1'] = {
                content: [
                    '# CLI PowerShell Application',
                    'param(',
                    '    [string]$Action,',
                    '    [string]$Target',
                    ')',
                    '',
                    'function Show-Usage {',
                    '    Write-Host "CLI PowerShell Application Template"',
                    '    Write-Host "Usage: .\\main.ps1 -Action [action] -Target [target]"',
                    '    Write-Host "Actions: get, set, remove"',
                    '}',
                    '',
                    'if (-not $Action) {',
                    '    Show-Usage',
                    '    exit',
                    '}',
                    '',
                    'switch ($Action) {',
                    '    "get" {',
                    '        Write-Host "Getting information from $Target"',
                    '        # Add your get logic here',
                    '    }',
                    '    "set" {',
                    '        Write-Host "Setting information for $Target"',
                    '        # Add your set logic here',
                    '    }',
                    '    "remove" {',
                    '        Write-Host "Removing $Target"',
                    '        # Add your remove logic here',
                    '    }',
                    '    default {',
                    '        Show-Usage',
                    '    }',
                    '}',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        case 'gui-app':
            projectFiles['main.ps1'] = {
                content: [
                    '# GUI PowerShell Application',
                    'Add-Type -AssemblyName System.Windows.Forms',
                    '',
                    '# Create form',
                    '$form = New-Object System.Windows.Forms.Form',
                    '$form.Text = "My Application"',
                    '$form.Size = New-Object System.Drawing.Size(500,400)',
                    '$form.StartPosition = "CenterScreen"',
                    '$form.BackColor = "White"',
                    '',
                    '# Create label',
                    '$label = New-Object System.Windows.Forms.Label',
                    '$label.Text = "Welcome to PowerShell GUI App"',
                    '$label.Location = New-Object System.Drawing.Point(20,20)',
                    '$label.Size = New-Object System.Drawing.Size(400,20)',
                    '$label.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)',
                    '$form.Controls.Add($label)',
                    '',
                    '# Create button',
                    '$button = New-Object System.Windows.Forms.Button',
                    '$button.Text = "Click Me"',
                    '$button.Location = New-Object System.Drawing.Point(200,100)',
                    '$button.Size = New-Object System.Drawing.Size(100,30)',
                    '$button.BackColor = "LightBlue"',
                    '$button.FlatStyle = "Flat"',
                    '$button.Add_Click({',
                    '    [System.Windows.Forms.MessageBox]::Show("Hello from PowerShell GUI!", "Message")',
                    '})',
                    '$form.Controls.Add($button)',
                    '',
                    '# Create textbox',
                    '$textbox = New-Object System.Windows.Forms.TextBox',
                    '$textbox.Location = New-Object System.Drawing.Point(20,150)',
                    '$textbox.Size = New-Object System.Drawing.Size(450,20)',
                    '$textbox.Text = "Enter text here"',
                    '$form.Controls.Add($textbox)',
                    '',
                    '# Show form',
                    '$form.ShowDialog() | Out-Null',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        case 'batch-utility':
            projectFiles['utility.bat'] = {
                content: [
                    '@echo off',
                    'REM Batch Utility Script',
                    'REM This template provides common batch utility functions',
                    '',
                    ':menu',
                    'cls',
                    'echo ================================',
                    'echo     Batch Utility Menu',
                    'echo ================================',
                    'echo 1. List files in directory',
                    'echo 2. Create backup of file',
                    'echo 3. Show system information',
                    'echo 4. Exit',
                    'echo ================================',
                    'set /p choice="Enter choice: "',
                    '',
                    'if "%choice%"=="1" goto list_files',
                    'if "%choice%"=="2" goto backup_file',
                    'if "%choice%"=="3" goto system_info',
                    'if "%choice%"=="4" goto exit',
                    'goto menu',
                    '',
                    ':list_files',
                    'echo Listing files in current directory:',
                    'dir',
                    'pause',
                    'goto menu',
                    '',
                    ':backup_file',
                    'set /p filename="Enter filename to backup: "',
                    'if exist "%filename%" (',
                    '    copy "%filename%" "%filename%.bak"',
                    '    echo Backup created as %filename%.bak',
                    ') else (',
                    '    echo File not found!',
                    ')',
                    'pause',
                    'goto menu',
                    '',
                    ':system_info',
                    'echo System Information:',
                    'systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type"',
                    'pause',
                    'goto menu',
                    '',
                    ':exit',
                    'echo Exiting utility...',
                    'exit /b',
                    ''
                ].join('\n'),
                language: 'batch'
            };
            break;
            
        case 'module-project':
            projectFiles['MyModule.psm1'] = {
                content: [
                    '# My PowerShell Module',
                    '',
                    'function Get-MyData {',
                    '    [CmdletBinding()]',
                    '    param(',
                    '        [Parameter(Mandatory=$true)]',
                    '        [string]$InputParameter',
                    '    )',
                    '    ',
                    '    Write-Host "Getting data for $InputParameter"',
                    '    # Add your logic here',
                    '}',
                    '',
                    'function Set-MyData {',
                    '    [CmdletBinding()]',
                    '    param(',
                    '        [Parameter(Mandatory=$true)]',
                    '        [string]$InputParameter',
                    '    )',
                    '    ',
                    '    Write-Host "Setting data for $InputParameter"',
                    '    # Add your logic here',
                    '}',
                    '',
                    'Export-ModuleMember -Function Get-MyData, Set-MyData',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            
            projectFiles['MyModule.psd1'] = {
                content: [
                    '@{',
                    '    ModuleToProcess = "MyModule.psm1"',
                    '    ModuleVersion = "1.0.0"',
                    '    GUID = "12345678-1234-1234-1234-123456789012"',
                    '    Author = "Your Name"',
                    '    CompanyName = "Your Company"',
                    '    Copyright = "(c) 2025 Your Name. All rights reserved."',
                    '    Description = "A sample PowerShell module"',
                    '    PowerShellVersion = "5.1"',
                    '    FunctionsToExport = @("Get-MyData", "Set-MyData")',
                    '    CmdletsToExport = @()',
                    '    VariablesToExport = @()',
                    '    AliasesToExport = @()',
                    '}',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        default:
            // Create a simple default file
            projectFiles['script.ps1'] = {
                content: '# PowerShell Script\nWrite-Host "Hello, World!"\n',
                language: 'powershell'
            };
    }
    
    // Update sidebar
    updateSidebar();
    
    // Load first file in editor
    const firstFile = Object.keys(projectFiles)[0];
    if (firstFile) {
        currentFileName = firstFile;
        editor.setValue(projectFiles[firstFile].content);
        currentLanguage = projectFiles[firstFile].language;
        monaco.editor.setModelLanguage(editor.getModel(), currentLanguage);
        document.querySelector('.status-bar div:first-child').innerHTML = 
            currentLanguage === 'powershell' ? 
            '<i class="fas fa-code"></i> PowerShell Mode' : 
            '<i class="fas fa-code"></i> Batch Mode';
    }
    
    // Show creation confirmation
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> Project template '${templateName}' created successfully\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Update editor tab
function updateEditorTab(fileName) {
    const tabs = document.querySelectorAll('.editor-tab');
    tabs.forEach(tab => {
        if (tab.textContent === fileName) {
            switchEditorTab(tab);
        }
    });
}

// Update sidebar with project files
function updateSidebar() {
    const sidebarContent = document.querySelector('.sidebar-content');
    
    // Clear current sidebar content except project folder
    while (sidebarContent.children.length > 1) {
        sidebarContent.removeChild(sidebarContent.lastChild);
    }
    
    // Add files to sidebar
    for (const fileName in projectFiles) {
        const fileItem = document.createElement('div');
        fileItem.className = 'sidebar-item';
        fileItem.innerHTML = '<i class="fas fa-file-code"></i> <span>' + fileName + '</span>';
        fileItem.addEventListener('click', function() {
            selectSidebarItem(this, fileName);
        });
        sidebarContent.appendChild(fileItem);
    }
}

// Save file
function saveFile() {
    // Get current content from editor
    const content = editor.getValue();
    
    // Update project file
    if (projectFiles[currentFileName]) {
        projectFiles[currentFileName].content = content;
    } else {
        // Create new file entry
        projectFiles[currentFileName] = {
            content: content,
            language: currentLanguage
        };
    }
    
    // Show save confirmation
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> File ${currentFileName} saved successfully\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Open file
function openFile() {
    // In a real implementation, this would open a file dialog
    // For this demo, we'll just show a message
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> Open file dialog would appear here\n`;
    outputContent.innerHTML += `> Select a .ps1 or .cmd/.bat file to open\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Run script
function runScript() {
    const outputContent = document.querySelector('.output-content');
    const scriptContent = editor.getValue();
    
    // Add execution message to output
    outputContent.innerHTML += `\n\n> Executing script...\n`;
    outputContent.innerHTML += `> Script content:\n${scriptContent}\n`;
    outputContent.innerHTML += `\n> Script executed successfully (simulated output)\n`;
    outputContent.innerHTML += `Hello from PowerShell/Batch Visual IDE!\n`;
    outputContent.innerHTML += `Execution completed at ${new Date().toLocaleTimeString()}\n`;
    
    // Scroll to bottom of output
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Debug script
function debugScript() {
    const outputContent = document.querySelector('.output-content');
    
    // Add debugging message to output
    outputContent.innerHTML += `\n\n> Debugging script...\n`;
    outputContent.innerHTML += `> Setting breakpoints...\n`;
    outputContent.innerHTML += `> Starting debug session...\n`;
    outputContent.innerHTML += `> Debug session started (simulated)\n`;
    
    // Scroll to bottom of output
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Stop script
function stopScript() {
    const outputContent = document.querySelector('.output-content');
    
    // Add stop message to output
    outputContent.innerHTML += `\n\n> Stopping script execution...\n`;
    outputContent.innerHTML += `> Script execution stopped\n`;
    
    // Scroll to bottom of output
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Clear output
function clearOutput() {
    document.querySelector('.output-content').innerHTML = '';
}

// Open Module Manager
function openModuleManager() {
    document.getElementById('moduleManagerModal').style.display = 'flex';
    
    // Add event listeners to import buttons
    document.querySelectorAll('.module-item .btn').forEach(button => {
        button.addEventListener('click', function() {
            importModule(this);
        });
    });
}

// Import module into current script
function importModule(button) {
    const moduleItem = button.closest('.module-item');
    const moduleName = moduleItem.querySelector('h5').textContent;
    
    // Get current content from editor
    const content = editor.getValue();
    
    // Add import statement at the beginning of the script
    const importStatement = `Import-Module ${moduleName}\n`;
    const newContent = importStatement + content;
    
    // Update editor
    editor.setValue(newContent);
    
    // Show import confirmation
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> Module ${moduleName} imported successfully\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
    
    // Close modal
    document.getElementById('moduleManagerModal').style.display = 'none';
}

// Select sidebar item
function selectSidebarItem(item, fileName) {
    // Remove active class from all sidebar items
    document.querySelectorAll('.sidebar-item').forEach(i => {
        i.classList.remove('active');
    });
    
    // Add active class to selected item
    item.classList.add('active');
    
    // If it's a file, load it in the editor
    if (item.querySelector('i').classList.contains('fa-file-code')) {
        // Use fileName parameter if provided, otherwise extract from item
        const fileToLoad = fileName || item.querySelector('span').textContent;
        currentFileName = fileToLoad;
        
        // Load file content in editor
        if (projectFiles[fileToLoad]) {
            editor.setValue(projectFiles[fileToLoad].content);
            
            // Switch language mode
            if (fileToLoad.includes('.ps1')) {
                currentLanguage = 'powershell';
                monaco.editor.setModelLanguage(editor.getModel(), 'powershell');
                document.querySelector('.status-bar div:first-child').innerHTML = '<i class="fas fa-code"></i> PowerShell Mode';
            } else if (fileToLoad.includes('.cmd') || fileToLoad.includes('.bat')) {
                currentLanguage = 'batch';
                monaco.editor.setModelLanguage(editor.getModel(), 'batch');
                document.querySelector('.status-bar div:first-child').innerHTML = '<i class="fas fa-code"></i> Batch Mode';
            }
        }
    }
}

// Select GUI component
function selectGuiComponent(component) {
    const componentName = component.getAttribute('data-component');
    
    // Add component to editor at cursor position
    const editorContent = editor.getValue();
    let newContent = editorContent;
    
    switch (componentName) {
        case 'window':
            newContent += '\n# Window Component\n$form = New-Object System.Windows.Forms.Form\n';
            break;
        case 'button':
            newContent += '\n# Button Component\n$button = New-Object System.Windows.Forms.Button\n';
            break;
        case 'textbox':
            newContent += '\n# TextBox Component\n$textbox = New-Object System.Windows.Forms.TextBox\n';
            break;
        case 'label':
            newContent += '\n# Label Component\n$label = New-Object System.Windows.Forms.Label\n';
            break;
        case 'checkbox':
            newContent += '\n# CheckBox Component\n$checkbox = New-Object System.Windows.Forms.CheckBox\n';
            break;
        case 'listbox':
            newContent += '\n# ListBox Component\n$listbox = New-Object System.Windows.Forms.ListBox\n';
            break;
        case 'combobox':
            newContent += '\n# ComboBox Component\n$combobox = New-Object System.Windows.Forms.ComboBox\n';
            break;
        case 'datagrid':
            newContent += '\n# DataGrid Component\n$datagrid = New-Object System.Windows.Forms.DataGridView\n';
            break;
    }
    
    editor.setValue(newContent);
}

// Open GUI Builder
function openGuiBuilder() {
    // Create a new GUI script if one doesn't exist
    if (!projectFiles['gui_app.ps1']) {
        projectFiles['gui_app.ps1'] = {
            content: [
                '# PowerShell GUI Application',
                'Add-Type -AssemblyName System.Windows.Forms',
                '',
                '# Create form',
                '$form = New-Object System.Windows.Forms.Form',
                '$form.Text = "My Application"',
                '$form.Size = New-Object System.Drawing.Size(400,300)',
                '$form.StartPosition = "CenterScreen"',
                '',
                '# Add controls here',
                '# Example:',
                '# $button = New-Object System.Windows.Forms.Button',
                '# $button.Text = "Click Me"',
                '# $button.Location = New-Object System.Drawing.Point(150,100)',
                '# $form.Controls.Add($button)',
                '',
                '# Show form',
                '$form.ShowDialog() | Out-Null',
                ''
            ].join('\n'),
            language: 'powershell'
        };
        
        // Update sidebar
        updateSidebar();
    }
    
    // Load the GUI script in the editor
    currentFileName = 'gui_app.ps1';
    editor.setValue(projectFiles['gui_app.ps1'].content);
    currentLanguage = 'powershell';
    monaco.editor.setModelLanguage(editor.getModel(), 'powershell');
    document.querySelector('.status-bar div:first-child').innerHTML = '<i class="fas fa-code"></i> PowerShell Mode';
    
    // Show message in output
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> GUI Builder activated\n`;
    outputContent.innerHTML += `> Loaded gui_app.ps1 for visual design\n`;
    outputContent.innerHTML += `> Drag and drop components from the GUI panel to add them to your application\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Create project from selected template
function createProject() {
    // Get selected template
    const selectedTemplate = document.querySelector('.template-item[style*="border-color"]');
    if (!selectedTemplate) {
        alert('Please select a template');
        return;
    }
    
    const templateName = selectedTemplate.getAttribute('data-template');
    
    // Clear existing project files
    projectFiles = {};
    
    // Add template files based on project type
    switch (templateName) {
        case 'cli-app':
            projectFiles['main.ps1'] = {
                content: [
                    '# CLI PowerShell Application',
                    'param(',
                    '    [string]$Action,',
                    '    [string]$Target',
                    ')',
                    '',
                    'function Show-Usage {',
                    '    Write-Host "CLI PowerShell Application Template"',
                    '    Write-Host "Usage: .\\main.ps1 -Action [action] -Target [target]"',
                    '    Write-Host "Actions: get, set, remove"',
                    '}',
                    '',
                    'if (-not $Action) {',
                    '    Show-Usage',
                    '    exit',
                    '}',
                    '',
                    'switch ($Action) {',
                    '    "get" {',
                    '        Write-Host "Getting information from $Target"',
                    '        # Add your get logic here',
                    '    }',
                    '    "set" {',
                    '        Write-Host "Setting information for $Target"',
                    '        # Add your set logic here',
                    '    }',
                    '    "remove" {',
                    '        Write-Host "Removing $Target"',
                    '        # Add your remove logic here',
                    '    }',
                    '    default {',
                    '        Show-Usage',
                    '    }',
                    '}',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        case 'gui-app':
            projectFiles['main.ps1'] = {
                content: [
                    '# GUI PowerShell Application',
                    'Add-Type -AssemblyName System.Windows.Forms',
                    '',
                    '# Create form',
                    '$form = New-Object System.Windows.Forms.Form',
                    '$form.Text = "My Application"',
                    '$form.Size = New-Object System.Drawing.Size(500,400)',
                    '$form.StartPosition = "CenterScreen"',
                    '$form.BackColor = "White"',
                    '',
                    '# Create label',
                    '$label = New-Object System.Windows.Forms.Label',
                    '$label.Text = "Welcome to PowerShell GUI App"',
                    '$label.Location = New-Object System.Drawing.Point(20,20)',
                    '$label.Size = New-Object System.Drawing.Size(400,20)',
                    '$label.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)',
                    '$form.Controls.Add($label)',
                    '',
                    '# Create button',
                    '$button = New-Object System.Windows.Forms.Button',
                    '$button.Text = "Click Me"',
                    '$button.Location = New-Object System.Drawing.Point(200,100)',
                    '$button.Size = New-Object System.Drawing.Size(100,30)',
                    '$button.BackColor = "LightBlue"',
                    '$button.FlatStyle = "Flat"',
                    '$button.Add_Click({',
                    '    [System.Windows.Forms.MessageBox]::Show("Hello from PowerShell GUI!", "Message")',
                    '})',
                    '$form.Controls.Add($button)',
                    '',
                    '# Create textbox',
                    '$textbox = New-Object System.Windows.Forms.TextBox',
                    '$textbox.Location = New-Object System.Drawing.Point(20,150)',
                    '$textbox.Size = New-Object System.Drawing.Size(450,20)',
                    '$textbox.Text = "Enter text here"',
                    '$form.Controls.Add($textbox)',
                    '',
                    '# Show form',
                    '$form.ShowDialog() | Out-Null',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        case 'batch-utility':
            projectFiles['utility.bat'] = {
                content: [
                    '@echo off',
                    'REM Batch Utility Script',
                    'REM This template provides common batch utility functions',
                    '',
                    ':menu',
                    'cls',
                    'echo ================================',
                    'echo     Batch Utility Menu',
                    'echo ================================',
                    'echo 1. List files in directory',
                    'echo 2. Create backup of file',
                    'echo 3. Show system information',
                    'echo 4. Exit',
                    'echo ================================',
                    'set /p choice="Enter choice: "',
                    '',
                    'if "%choice%"=="1" goto list_files',
                    'if "%choice%"=="2" goto backup_file',
                    'if "%choice%"=="3" goto system_info',
                    'if "%choice%"=="4" goto exit',
                    'goto menu',
                    '',
                    ':list_files',
                    'echo Listing files in current directory:',
                    'dir',
                    'pause',
                    'goto menu',
                    '',
                    ':backup_file',
                    'set /p filename="Enter filename to backup: "',
                    'if exist "%filename%" (',
                    '    copy "%filename%" "%filename%.bak"',
                    '    echo Backup created as %filename%.bak',
                    ') else (',
                    '    echo File not found!',
                    ')',
                    'pause',
                    'goto menu',
                    '',
                    ':system_info',
                    'echo System Information:',
                    'systeminfo | findstr /C:"OS Name" /C:"OS Version" /C:"System Type"',
                    'pause',
                    'goto menu',
                    '',
                    ':exit',
                    'echo Exiting utility...',
                    'exit /b',
                    ''
                ].join('\n'),
                language: 'batch'
            };
            break;
            
        case 'module-project':
            projectFiles['MyModule.psm1'] = {
                content: [
                    '# My PowerShell Module',
                    '',
                    'function Get-MyData {',
                    '    [CmdletBinding()]',
                    '    param(',
                    '        [Parameter(Mandatory=$true)]',
                    '        [string]$InputParameter',
                    '    )',
                    '    ',
                    '    Write-Host "Getting data for $InputParameter"',
                    '    # Add your logic here',
                    '}',
                    '',
                    'function Set-MyData {',
                    '    [CmdletBinding()]',
                    '    param(',
                    '        [Parameter(Mandatory=$true)]',
                    '        [string]$InputParameter',
                    '    )',
                    '    ',
                    '    Write-Host "Setting data for $InputParameter"',
                    '    # Add your logic here',
                    '}',
                    '',
                    'Export-ModuleMember -Function Get-MyData, Set-MyData',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            
            projectFiles['MyModule.psd1'] = {
                content: [
                    '@{',
                    '    ModuleToProcess = "MyModule.psm1"',
                    '    ModuleVersion = "1.0.0"',
                    '    GUID = "12345678-1234-1234-1234-123456789012"',
                    '    Author = "Your Name"',
                    '    CompanyName = "Your Company"',
                    '    Copyright = "(c) 2025 Your Name. All rights reserved."',
                    '    Description = "A sample PowerShell module"',
                    '    PowerShellVersion = "5.1"',
                    '    FunctionsToExport = @("Get-MyData", "Set-MyData")',
                    '    CmdletsToExport = @()',
                    '    VariablesToExport = @()',
                    '    AliasesToExport = @()',
                    '}',
                    ''
                ].join('\n'),
                language: 'powershell'
            };
            break;
            
        default:
            // Create a simple default file
            projectFiles['script.ps1'] = {
                content: '# PowerShell Script\nWrite-Host "Hello, World!"\n',
                language: 'powershell'
            };
    }
    
    // Update sidebar
    updateSidebar();
    
    // Load first file in editor
    const firstFile = Object.keys(projectFiles)[0];
    if (firstFile) {
        currentFileName = firstFile;
        editor.setValue(projectFiles[firstFile].content);
        currentLanguage = projectFiles[firstFile].language;
        monaco.editor.setModelLanguage(editor.getModel(), currentLanguage);
        document.querySelector('.status-bar div:first-child').innerHTML = 
            currentLanguage === 'powershell' ? 
            '<i class="fas fa-code"></i> PowerShell Mode' : 
            '<i class="fas fa-code"></i> Batch Mode';
    }
    
    // Close modal
    document.getElementById('newProjectModal').style.display = 'none';
    
    // Show creation confirmation
    const outputContent = document.querySelector('.output-content');
    outputContent.innerHTML += `\n> Project template '${templateName}' created successfully\n`;
    outputContent.scrollTop = outputContent.scrollHeight;
}

// Update status bar with current line/column
function updateStatusBar() {
    editor.onDidChangeCursorPosition(function(e) {
        const position = e.position;
        document.querySelector('.status-bar div:last-child').innerHTML = 
            `<i class="fas fa-code-branch"></i> Line ${position.lineNumber}, Column ${position.column}`;
    });
}